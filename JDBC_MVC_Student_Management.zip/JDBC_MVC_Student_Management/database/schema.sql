CREATE DATABASE IF NOT EXISTS college;
USE college;

CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    course VARCHAR(100) NOT NULL
);

INSERT INTO students(name, age, course)
SELECT 'Dineel', 21, 'CSE'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE name = 'Dineel');
