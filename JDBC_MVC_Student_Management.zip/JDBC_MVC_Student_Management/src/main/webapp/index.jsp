<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Student Management - JDBC MVC</title>
    <style>
        body{font-family:Arial;background:#f4f7fb;margin:0;padding:30px}
        .box{max-width:900px;margin:auto;background:white;padding:25px;border-radius:16px;
             box-shadow:0 8px 30px #0001}
        h1{margin-top:0}
        form{display:grid;grid-template-columns:1fr 120px 1fr auto;gap:10px;margin-bottom:25px}
        input,button{padding:11px;border:1px solid #ccc;border-radius:8px}
        button{cursor:pointer;background:#1f6feb;color:white;border:0}
        table{width:100%;border-collapse:collapse}
        th,td{padding:12px;border-bottom:1px solid #eee;text-align:left}
        .delete{background:#d73a49}
        @media(max-width:700px){form{grid-template-columns:1fr}.box{padding:15px}}
    </style>
</head>
<body>
<div class="box">
    <h1>Student Management System</h1>

    <form method="post" action="${pageContext.request.contextPath}/students">
        <input type="hidden" name="action" value="add">
        <input name="name" placeholder="Student name" required>
        <input name="age" type="number" min="1" placeholder="Age" required>
        <input name="course" placeholder="Course" required>
        <button type="submit">Add Student</button>
    </form>

    <table>
        <tr>
            <th>ID</th><th>Name</th><th>Age</th><th>Course</th><th>Delete</th>
        </tr>
        <c:forEach var="s" items="${students}">
            <tr>
                <td>${s.id}</td>
                <td>${s.name}</td>
                <td>${s.age}</td>
                <td>${s.course}</td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/students"
                          style="display:inline">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="${s.id}">
                        <button class="delete" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>
